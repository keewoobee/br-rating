export interface MenuItem {
  id: number;
  name: string;
  tags?: string[];
  kcal?: number;
  imageUrl?: string;
  englishName?: string;
  description?: string;
  components?: string[];
  nutrition?: Record<string, string>;
}

export interface TierInfo {
  name: string;
  minCount: number;
  color: string;
  imageUrl: string;
}

export const tiers: TierInfo[] = [
  { 
    name: '싱글레귤러', 
    minCount: 0, 
    color: 'bg-pink-100 text-pink-600', 
    imageUrl: 'https://i.namu.wiki/i/3aD-AwNx2E7TOG59LUZnazaTs0OAWZMQB8fXbd1XoONQjJubXd00lqHdAESVZ8ZGNjfqnb5VW3dNPi1Ee9HvpeQe-qC82wtpzPtjsbkvsgNzluktn8FwBU_vKCwK3QtjZpV7kTdO9PvN4ob4uW9l6w.webp'
  },
  { 
    name: '싱글킹', 
    minCount: 5, 
    color: 'bg-pink-200 text-pink-700', 
    imageUrl: 'https://i.namu.wiki/i/9_YOlP6Dd44RZjNasQW_OU_DqH-qbG_g1XS2vpH5en0gGJEe1-ifg2gwQGpflFAHRG6zbW3FWVI1ccB3a8QoRZaaYxUwKAsVKwBa-3VnCgqMCkaSuA9qnorI0MqUbu7IJNqhh6zG2VbirRb-krqp4w.webp'
  },
  { 
    name: '더블주니어', 
    minCount: 10, 
    color: 'bg-orange-100 text-orange-600', 
    imageUrl: 'https://i.namu.wiki/i/O3rtV0o7E80P2KQzMxO1AFZny4drIWymyXzEOCM7nkZcMnZJHNFM8fq3wG0Q8RGngj8L72HO3NHhyLYIh2MPtN7McoqgsTsVN44Ide7OxvWHK9MxiyGxyXH83FWgVHhUMDNkgygMVHpMOqe8vHK4tw.webp'
  },
  { 
    name: '더블레귤러', 
    minCount: 15, 
    color: 'bg-yellow-100 text-yellow-600', 
    imageUrl: 'https://i.namu.wiki/i/71gnsusKvtYUnd-SLDIZ3v_pDx9MRanXbhzWT13oLR0lIIb92j6-TwleOqJJAY3_0TGQSrdVpMr7-sZcOE4LN3KN_S8aoqhzWqk5SXj1B-hE5RS6rwTqTa1Z-lRJLhYQ5srcb2snnNcuHCVRf7xqpw.webp'
  },
  { 
    name: '파인트', 
    minCount: 20, 
    color: 'bg-yellow-200 text-yellow-700', 
    imageUrl: 'https://i.namu.wiki/i/M7iXqPQ5g7szTtcCNJqaP6XcaBP6e5NUP37JfDVB_1k6r1Hr8pOI4Q1RY92CYLeNMJyfxr6WdbxBxne0eUJrlHn5cFC8QZq0CHfep8jQgLx7XKG3vLNystBhRIyOf0fFMRO-pbpLjIB14nVi_EdTVQ.webp'
  },
  { 
    name: '쿼터', 
    minCount: 25, 
    color: 'bg-blue-100 text-blue-600', 
    imageUrl: 'https://i.namu.wiki/i/Lnb5qDK67HbW09G2NSQSbK3BPg8YVGZHCTtmmj_wJKhg6e8TzTWOb7LhTE5vVtcgMb6R1xxXC9l9o2g64IpVjUzR--do-ULTV6uCzOq4t0zOdAmLgu1ViaXx9d5sQ4SGll3Gg05Zw5ZTOk3FRawubQ.webp'
  },
  { 
    name: '패밀리', 
    minCount: 35, 
    color: 'bg-blue-200 text-blue-700', 
    imageUrl: 'https://i.namu.wiki/i/v45YzDSjdW8r8P7BqbpFIV_GtqKXeRyp7vY7LuAwINpq-z5phenRzgGMhizcOrJkPvy0oTzH8wrTfMBRiPrKpPFkY12e5KXCBiQJ5vTfGNUGc592C-2Nt_OMWf-1eD8aob6cjChj1YvGZK90uH5MYA.webp'
  },
  { 
    name: '하프갤런', 
    minCount: 45, 
    color: 'bg-purple-100 text-purple-600', 
    imageUrl: 'https://i.namu.wiki/i/JlgOwjrOfpeYKAhqU55ve9BVaKiAadTVYxh6u65a3CDMl9sYdbDjPhWDffN4nbO10r89sxC-j-u6QSoRBR-vAaGg6k1KgA7DyTuSAw7q9POZd_UXTylSJawWFyx1koaMu8barDwiidvSh1FptfH_PQ.webp'
  },
];

export const getTier = (count: number): TierInfo => {
  for (let i = tiers.length - 1; i >= 0; i--) {
    if (count >= tiers[i].minCount) {
      return tiers[i];
    }
  }
  return tiers[0];
};

export const menuData: MenuItem[] = [
  {
    "id": 1,
    "name": "두바이에서 온 엄마는 외계인",
    "tags": [
      "이달의맛",
      "2026년",
      "3월",
      "초콜릿",
      "피스타치오",
      "카다이프"
    ],
    "kcal": 295,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/60b01f68d496cc0ce0ba1709dbd83cd8.png",
    "englishName": "ICE PISTACHIO & CHOCOLATE WITH KADAYIF",
    "description": "리얼 카다이프가 들어간 피스타치오&초콜릿 아이스크림에 초콜릿 쫀떡볼이 쏙쏙!",
    "components": [
      "초콜릿",
      "피스타치오",
      "카다이프"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "295",
      "당류(g)": "24",
      "단백질(g)": "5",
      "포화지방(g)": "8",
      "나트륨(mg)": "153",
      "알레르기 성분": "우유, 밀, 대두"
    }
  },
  {
    "id": 2,
    "name": "진정한 쫀꾸렛",
    "tags": [
      "다크초코",
      "꾸덕함",
      "이달의맛",
      "2026년",
      "2월"
    ],
    "kcal": 265,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/844cfcfe15d53bc82123dc0245358999.png",
    "englishName": "The Real Crunchy & Fudge Chocolate Ice cream",
    "description": "바삭, 쫀득, 꾸덕한 초콜렛 아이스크림! 사랑스러운 핑크 초콜릿 향& 초콜릿 아이스크림에 초콜릿 쿠키와 브라우니가 가득",
    "components": [
      "초콜릿 칩",
      "브라우니",
      "핑크초콜릿"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "265",
      "당류(g)": "26",
      "단백질(g)": "4",
      "포화지방(g)": "9",
      "나트륨(mg)": "97",
      "알레르기 성분": "우유, 대두, 밀, 계란"
    }
  },
  {
    "id": 3,
    "name": "쫀득 만난 흑임자",
    "tags": [
      "흑임자",
      "떡",
      "고소함"
    ],
    "kcal": 259,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/487607c1da24aacedec8399f06cb61ee.png",
    "englishName": "CHEWY RICE CAKE & BLACK SESAME ICE CREAM",
    "description": "국내산 100% 쌀 아이스크림 속 쫀득한 쌀떡과 고소한 흑임자 풍미가 가득",
    "components": [
      "쌀",
      "흑임자떡"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "259",
      "당류(g)": "25",
      "단백질(g)": "3",
      "포화지방(g)": "5",
      "나트륨(mg)": "134",
      "알레르기 성분": "우유, 밀, 대두, 계란, 오징어"
    }
  },
  {
    "id": 4,
    "name": "말랑 꿀떡 모찌",
    "tags": [
      "꿀",
      "모찌",
      "달콤"
    ],
    "kcal": 246,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/b7c0a60e615c0739e1d253d7272f1e17.png",
    "englishName": "Chewy Kkultteock Mochi",
    "description": "고소한 참깨 아이스크림에 달콤한 꿀참깨 리본과 쫀득한 떡 다이스가 쏙쏙!",
    "components": [
      "떡",
      "꿀참깨"
    ],
    "nutrition": {
      "1회 제공량(g)": "115 g",
      "열량(kcal)": "246",
      "당류(g)": "31",
      "단백질(g)": "3",
      "포화지방(g)": "6",
      "나트륨(mg)": "88",
      "알레르기 성분": "우유, 대두, 밀"
    }
  },
  {
    "id": 5,
    "name": "아이스 호떡",
    "tags": [
      "호떡",
      "견과류",
      "이달의맛",
      "2020년",
      "11월"
    ],
    "kcal": 286,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/1f0853765bc0cab886e39c2ebc275d29.png",
    "englishName": "Ice Hotteok",
    "description": "달콤한 호떡맛 아이스크림에 호떡 시럽리본과 씨앗, 떡 다이스가 어우러진 아이스크림",
    "components": [
      "호떡",
      "견과류"
    ],
    "nutrition": {
      "1회 제공량(g)": "115 g",
      "열량(kcal)": "286",
      "당류(g)": "29",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "85",
      "알레르기 성분": "우유, 대두, 밀, 땅콩"
    }
  },
  {
    "id": 6,
    "name": "밤이 옥수로 맛있구마",
    "tags": [
      "밤",
      "옥수수",
      "고구마"
    ],
    "kcal": 236,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/97cefc01e3af561597c02f67929e2320.png",
    "englishName": "MARON, CORN, AND SWEET POTATO",
    "description": "아이스크림으로 즐기는 추억의 간식. 밤, 옥수수, 고구마",
    "components": [
      "밤",
      "옥수수",
      "고구마"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "236",
      "당류(g)": "21",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "76",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 7,
    "name": "크림치즈 피치 타르트",
    "tags": [
      "복숭아",
      "크림치즈"
    ],
    "kcal": 231,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/d284730e20d7364e2f210ff3f7354134.png",
    "englishName": "Cream Cheese Peach Tart",
    "description": "부드러운 크림치즈에 달콤한 복숭아를 올리고 타르트의 식감을 살린 아이스크림",
    "components": [
      "타르트 크럼블",
      "구운복숭아과육"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "231",
      "당류(g)": "23",
      "단백질(g)": "4",
      "포화지방(g)": "7",
      "나트륨(mg)": "89",
      "알레르기 성분": "우유, 밀, 복숭아"
    }
  },
  {
    "id": 8,
    "name": "아이스 꼬북칩",
    "tags": [
      "콘스프",
      "초코칩",
      "바삭",
      "이달의맛",
      "2021년",
      "8월"
    ],
    "kcal": 284,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/01b945440bbb79c034a7eb6672e5fea4.png",
    "englishName": "ICE TURTLE CHIP",
    "description": "바삭한 꼬북칩과  달콤한 시나몬 초콜릿의 완벽한 만남!",
    "components": [
      "꼬북칩"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "284",
      "당류(g)": "25",
      "단백질(g)": "4",
      "포화지방(g)": "10",
      "나트륨(mg)": "95",
      "알레르기 성분": "우유, 대두, 밀"
    }
  },
  {
    "id": 9,
    "name": "치즈 고구마구마",
    "tags": [
      "고구마",
      "치즈케이크",
      "이달의맛",
      "2021년",
      "10월"
    ],
    "kcal": 245,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/58ffabb1d3e4642f50752553ebfb3067.png",
    "englishName": "CHEESE & SWEET POTATO",
    "description": "고구마 아이스크림, 크림치즈 아이스크림에 고소한 고구마와 고구마 치크케이크가 쏘옥!",
    "components": [
      "크림치즈",
      "고구마"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "245",
      "당류(g)": "21",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "84",
      "알레르기 성분": "우유, 대두, 밀, 계란"
    }
  },
  {
    "id": 10,
    "name": "(Lessly Edition) 아몬드 봉봉",
    "tags": [
      "아몬드",
      "초코",
      "저당"
    ],
    "kcal": 162,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/e511aa903274e35ed11287f59cc924df.png",
    "englishName": "(Lessly Edition) Almond Bonbon",
    "description": "맛은 그대로! 당류 & 칼로리는 더 가볍게~ 자사 기존 제품 대비 당류 30%, 칼로리 48% 낮아진 아몬드 봉봉",
    "components": [
      "바닐라",
      "밀크 초콜릿 시럽",
      "초코 아몬드"
    ],
    "nutrition": {
      "1회 제공량(g)": "115 g",
      "열량(kcal)": "162",
      "당류(g)": "18",
      "단백질(g)": "5",
      "포화지방(g)": "2.1",
      "나트륨(mg)": "80",
      "알레르기 성분": "우유, 대두"
    }
  },
  {
    "id": 11,
    "name": "(Lessly Edition) 엄마는 외계인",
    "tags": [
      "초코볼",
      "저당"
    ],
    "kcal": 156,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/09ce6b140dad71186b063fbc77fa6617.png",
    "englishName": "(Lessly Edition) Puss In Boots",
    "description": "맛은 그대로! 당류 & 칼로리는 더 가볍게~ 자사 기존 제품 대비 당류 39%, 칼로리 47% 낮아진 엄마는 외계인",
    "components": [
      "밀크초콜릿",
      "화이트 무스",
      "다크 초콜릿",
      "초콜릿 칩",
      "초코 프레첼"
    ],
    "nutrition": {
      "1회 제공량(g)": "115 g",
      "열량(kcal)": "156",
      "당류(g)": "14",
      "단백질(g)": "5",
      "포화지방(g)": "3.8",
      "나트륨(mg)": "57",
      "알레르기 성분": "우유, 밀, 대두"
    }
  },
  {
    "id": 12,
    "name": "아몬드 봉봉",
    "tags": [
      "초콜릿",
      "아몬드",
      "바닐라"
    ],
    "kcal": 312,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/e7cb5667c3147ddb0b31e28d1f365980.png",
    "englishName": "Almond Bon Bon",
    "description": "입안 가득 즐거운 초콜릿, 아몬드로 더욱 달콤하게!",
    "components": [
      "바닐라",
      "밀크 초콜릿 시럽",
      "초코 아몬드"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "312",
      "당류(g)": "26",
      "단백질(g)": "5",
      "포화지방(g)": "8",
      "나트륨(mg)": "94",
      "알레르기 성분": "우유, 대두"
    }
  },
  {
    "id": 13,
    "name": "엄마는 외계인",
    "tags": [
      "밀크초코",
      "다크초코",
      "초코볼"
    ],
    "kcal": 296,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/91c8668227bcf556c43a968b97e342e6.png",
    "englishName": "Puss In Boots",
    "description": "밀크 초콜릿, 다크 초콜릿, 화이트 무스 세 가지 아이스크림에 달콤 바삭한 초코볼이 더해진 아이스크림",
    "components": [
      "밀크초콜릿",
      "화이트 무스",
      "다크 초콜릿",
      "초콜릿 칩",
      "초코 프레첼"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "296",
      "당류(g)": "23",
      "단백질(g)": "5",
      "포화지방(g)": "11",
      "나트륨(mg)": "114",
      "알레르기 성분": "우유, 대두, 밀"
    }
  },
  {
    "id": 14,
    "name": "사랑에 빠진 딸기",
    "tags": [
      "딸기",
      "치즈케이크",
      "초코칩"
    ],
    "kcal": 292,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/fea066eec3455d92b954428498ad30b3.png",
    "englishName": "Love Struck Strawberry",
    "description": "딸기와 초콜릿이 치즈케이크에 반해버린 사랑의 맛",
    "components": [
      "치즈딸기",
      "크래클 퍼지",
      "치즈케이크 큐브",
      "딸기 과육"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "292",
      "당류(g)": "26",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "103",
      "알레르기 성분": "우유, 계란, 대두, 땅콩, 밀"
    }
  },
  {
    "id": 15,
    "name": "윈터 민트 초콜릿 칩",
    "tags": [
      "민트",
      "초코칩",
      "시원함"
    ],
    "kcal": 288,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/abf71fa2ad067aeb48964307e9f6140f.png",
    "englishName": "Winter Mint Chocolate Chip",
    "description": "상쾌한 민트 초콜릿 칩 아이스크림에 팝핑캔디가 쏙쏙!",
    "components": [
      "민트",
      "초콜릿 칩",
      "팝핑 캔디"
    ],
    "nutrition": {
      "1회 제공량(g)": "115 g",
      "열량(kcal)": "288",
      "당류(g)": "26",
      "단백질(g)": "4",
      "포화지방(g)": "10",
      "나트륨(mg)": "67",
      "알레르기 성분": "우유, 대두"
    }
  },
  {
    "id": 16,
    "name": "숭아야, 그릭다...",
    "tags": [
      "복숭아",
      "그릭요거트",
      "이달의맛",
      "2024년",
      "10월"
    ],
    "kcal": 198,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/cf976fedf77cf2f6599656dd6f7e8339.png",
    "englishName": "DEAR DONUT PEACH & GREEK YOGURT",
    "description": "한 입 먹는 순간 그리워질 달콤한 납작복숭아와 부드러운 그릭요거트, 바삭한 그래놀라의 조화!",
    "components": [
      "그릭 요거트",
      "납작 복숭아",
      "복숭아 과육",
      "그래놀라"
    ],
    "nutrition": {
      "1회 제공량(g)": "115 g",
      "열량(kcal)": "198",
      "당류(g)": "28",
      "단백질(g)": "4",
      "포화지방(g)": "4.1",
      "나트륨(mg)": "57",
      "알레르기 성분": "복숭아, 우유, 대두"
    }
  },
  {
    "id": 17,
    "name": "너 T(tea)야??",
    "tags": [
      "얼그레이",
      "카카오"
    ],
    "kcal": 259,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/d07eb9cc2b781a21cfa3f18932473478.png",
    "englishName": "EARL GREY & CHOCOLATE ICE CREAM",
    "description": "향긋한 얼그레이와 달콤한 초콜릿이 만난, F까지 반하게 할 T(Tea,차) 아이스크림!",
    "components": [
      "초콜릿",
      "얼그레이"
    ],
    "nutrition": {
      "1회 제공량(g)": "115 g",
      "열량(kcal)": "259",
      "당류(g)": "30",
      "단백질(g)": "5",
      "포화지방(g)": "7",
      "나트륨(mg)": "70",
      "알레르기 성분": "우유, 대두"
    }
  },
  {
    "id": 18,
    "name": "수박 Hero",
    "tags": [
      "수박",
      "샤베트"
    ],
    "kcal": 165,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/16c6b8173ad0f21ed0e53fed0ffc86cf.png",
    "englishName": "Watermelon Hero",
    "description": "수박 소르베와 밀크소다 샤베트, 파인애플 다이스의 영웅적 만남!",
    "components": [
      "파인애플",
      "수박"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "165",
      "당류(g)": "28",
      "단백질(g)": "0",
      "포화지방(g)": "0",
      "나트륨(mg)": "17",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 19,
    "name": "소금 우유 아이스크림",
    "tags": [
      "솔티",
      "우유맛"
    ],
    "kcal": 222,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/719e8584fd50151284b5ace3589f7a34.png",
    "englishName": "Salted Milk Ice Cream",
    "description": "부드러운 우유 맛 아이스크림 속에 깊은 단 맛을 끌어내는 소금 아이스크림",
    "components": [
      "소금우유"
    ],
    "nutrition": {
      "1회 제공량(g)": "115 g",
      "열량(kcal)": "222",
      "당류(g)": "22",
      "단백질(g)": "5",
      "포화지방(g)": "7",
      "나트륨(mg)": "266",
      "알레르기 성분": "우유, 대두"
    }
  },
  {
    "id": 20,
    "name": "애플 민트",
    "tags": [
      "사과",
      "민트",
      "샤베트"
    ],
    "kcal": 187,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/eec8cef386cf6697768a89b384c07bf7.png",
    "englishName": "APPLE MINT",
    "description": "상큼한 사과와 시원한 민트향이 기분까지 상쾌하게",
    "components": [
      "민트"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "187",
      "당류(g)": "22",
      "단백질(g)": "6",
      "포화지방(g)": "3.1",
      "나트륨(mg)": "29",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 21,
    "name": "아빠는 딸바봉",
    "tags": [
      "딸기",
      "바나나",
      "프레첼볼",
      "이달의맛",
      "2019년",
      "10월"
    ],
    "kcal": 308,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/abd67bc325966a949b24f08e75d8f1a7.png",
    "englishName": "Papa & Daughter Ice Cream",
    "description": "두가지 딸기 아이스크림과 바닐라향 아이스크림에 봉봉 프레첼이 쏘옥~!",
    "components": [
      "딸기",
      "바닐라",
      "딸기 크런치볼"
    ],
    "nutrition": {
      "1회 제공량(g)": "115 g",
      "열량(kcal)": "308",
      "당류(g)": "26",
      "단백질(g)": "4",
      "포화지방(g)": "14",
      "나트륨(mg)": "84",
      "알레르기 성분": "우유, 대두, 밀"
    }
  },
  {
    "id": 22,
    "name": "민트 초콜릿 칩",
    "tags": [
      "민트",
      "초코칩"
    ],
    "kcal": 259,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/fb92d70dee836652115c4f3b13175541.png",
    "englishName": "Mint Chocolate Chip",
    "description": "쿨한 당신의 선택! 상쾌한 민트향에 초코칩까지!",
    "components": [
      "민트",
      "초콜릿 칩"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "259",
      "당류(g)": "23",
      "단백질(g)": "4",
      "포화지방(g)": "9",
      "나트륨(mg)": "81",
      "알레르기 성분": "우유, 대두"
    }
  },
  {
    "id": 23,
    "name": "뉴욕 치즈케이크",
    "tags": [
      "치즈케이크",
      "그레이엄크래커"
    ],
    "kcal": 275,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/60a04a3a5d1b0119f065d12ee7797b2c.png",
    "englishName": "New York CheeseCake",
    "description": "부드럽게 즐기는 뉴욕식 정통 치즈케이크 아이스크림",
    "components": [
      "치즈",
      "그라함 크래커"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "275",
      "당류(g)": "21",
      "단백질(g)": "4",
      "포화지방(g)": "10",
      "나트륨(mg)": "105",
      "알레르기 성분": "우유, 대두, 밀"
    }
  },
  {
    "id": 24,
    "name": "레인보우 샤베트",
    "tags": [
      "파인애플",
      "오렌지",
      "라즈베리"
    ],
    "kcal": 163,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/5ad63f3af7244a666d981a1497a39fe7.png",
    "englishName": "Rainbow Sherbet",
    "description": "상큼한 파인애플, 오렌지, 라즈베리가 만드는 일곱빛깔 무지개",
    "components": [
      "오렌지",
      "파인애플",
      "라즈베리"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "163",
      "당류(g)": "25",
      "단백질(g)": "1",
      "포화지방(g)": "1.2",
      "나트륨(mg)": "15",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 25,
    "name": "체리쥬빌레",
    "tags": [
      "체리",
      "과육"
    ],
    "kcal": 239,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/f6609e3e3431d54beceeb1d3787403af.png",
    "englishName": "Cherries Jubilee",
    "description": "체리과육이 탱글탱글 씹히는 체리 아이스크림",
    "components": [
      "체리",
      "체리 과육"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "239",
      "당류(g)": "28",
      "단백질(g)": "3",
      "포화지방(g)": "7",
      "나트륨(mg)": "48",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 26,
    "name": "슈팅스타",
    "tags": [
      "톡톡캔디",
      "체리",
      "블루베리"
    ],
    "kcal": 260,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/a4b71e8b99743c93a7824331850b0a3d.png",
    "englishName": "Shooting Star",
    "description": "블루베리 & 바닐라향에 입안에서 톡톡 터지는 캔디와 신나는 축제",
    "components": [
      "블루베리",
      "바닐라",
      "체리 시럽",
      "블루 팝핑캔디"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "260",
      "당류(g)": "27",
      "단백질(g)": "3",
      "포화지방(g)": "7",
      "나트륨(mg)": "65",
      "알레르기 성분": "우유, 대두, 밀"
    }
  },
  {
    "id": 27,
    "name": "오레오 쿠키 앤 크림",
    "tags": [
      "오레오",
      "바닐라"
    ],
    "kcal": 254,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/414246bd9041530d6ad4d30d97aac87c.png",
    "englishName": "Oreo Cookie´s n Cream",
    "description": "부드러운 바닐라향 아이스크림에, 달콤하고 진한 오레오 쿠키가 듬뿍!",
    "components": [
      "바닐라",
      "오레오"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "254",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "92",
      "알레르기 성분": "우유, 대두, 밀"
    }
  },
  {
    "id": 28,
    "name": "베리베리 스트로베리",
    "tags": [
      "딸기",
      "과육"
    ],
    "kcal": 228,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/ea6608b4f72563b360da5c44c946ddc7.png",
    "englishName": "Very Berry Strawberry",
    "description": "새콤상큼 딸기 과육이 듬뿍!",
    "components": [
      "딸기",
      "딸기 과육"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "228",
      "당류(g)": "24",
      "단백질(g)": "3",
      "포화지방(g)": "7",
      "나트륨(mg)": "69",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 29,
    "name": "31요거트",
    "tags": [
      "상큼",
      "유산균"
    ],
    "kcal": 198,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/d56328637eaf86e3273ebc39c57aada7.png",
    "englishName": "31 Yogurt",
    "description": "유산균이 들어있는 오리지널 요거트 아이스크림",
    "components": [
      "요거트"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "198",
      "당류(g)": "26",
      "단백질(g)": "5",
      "포화지방(g)": "4",
      "나트륨(mg)": "67",
      "알레르기 성분": "우유, 대두"
    }
  },
  {
    "id": 30,
    "name": "바람과 함께 사라지다",
    "tags": [
      "블루베리",
      "딸기",
      "치즈케이크"
    ],
    "kcal": 269,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/01ecc320f5d3a6f32e5188eda373842d.png",
    "englishName": "Twinberry CheeseCake",
    "description": "블루베리와 딸기로 상큼함을 더한 치즈케이크 한 조각",
    "components": [
      "치즈",
      "블루베리 시럽",
      "딸기 시럽",
      "치즈케이크 큐브"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "269",
      "당류(g)": "25",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "95",
      "알레르기 성분": "우유, 대두, 밀, 계란"
    }
  },
  {
    "id": 31,
    "name": "이상한 나라의 솜사탕",
    "tags": [
      "솜사탕",
      "달콤",
      "2012년",
      "4월",
      "2016년",
      "5월"
    ],
    "kcal": 287,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/4db4f9967ad6f603837a40eede965ef0.png",
    "englishName": "Cotton Candy Wonderland",
    "description": "부드럽고 달콤한 솜사탕과 함께 떠나는 이상한 나라로의 여행",
    "components": [
      "옐로우 솜사탕",
      "핑크 솜사탕",
      "블루 솜사탕",
      "옐로우 크런치",
      "핑크 크런치"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "287",
      "당류(g)": "31",
      "단백질(g)": "5",
      "포화지방(g)": "10",
      "나트륨(mg)": "109",
      "알레르기 성분": "우유, 대두"
    }
  },
  {
    "id": 32,
    "name": "피스타치오 아몬드",
    "tags": [
      "피스타치오",
      "아몬드"
    ],
    "kcal": 302,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/868364b0ed6038d0c9aee0a10e50d4a9.png",
    "englishName": "Pistachio Almond",
    "description": "피스타치오와 아몬드가 만나 고소함이 두 배!",
    "components": [
      "피스타치오",
      "아몬드"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "302",
      "당류(g)": "27",
      "단백질(g)": "7",
      "포화지방(g)": "8",
      "나트륨(mg)": "72",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 33,
    "name": "초콜릿 무스",
    "tags": [
      "진한초코",
      "초코칩"
    ],
    "kcal": 318,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/0d67607c2ca4dde4ec24ac8109a343c2.png",
    "englishName": "Chocolate Mousse",
    "description": "초콜릿 칩이 들어있는 진한 초콜릿 아이스크림",
    "components": [
      "초콜릿 무스"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "318",
      "당류(g)": "27",
      "단백질(g)": "5",
      "포화지방(g)": "12",
      "나트륨(mg)": "96",
      "알레르기 성분": "우유, 대두"
    }
  },
  {
    "id": 34,
    "name": "그린티",
    "tags": [
      "녹차",
      "쌉싸름"
    ],
    "kcal": 245,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/a6bd7bcdd6bdb56f28df7e98f051abda.png",
    "englishName": "Green Tea",
    "description": "엄선된 녹차를 사용한 싱그러운 그린티 아이스크림",
    "components": [
      "그린티"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "245",
      "당류(g)": "20",
      "단백질(g)": "5",
      "포화지방(g)": "8",
      "나트륨(mg)": "73",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 35,
    "name": "자모카 아몬드 훠지",
    "tags": [
      "커피",
      "아몬드",
      "초콜릿리본"
    ],
    "kcal": 273,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/f31388da0371388c2086a7c90990a097.png",
    "englishName": "Jamoca\nAlmond Fudge",
    "description": "깊고 풍부한 자모카 아이스크림에 고소한 아몬드와 초콜릿 훠지 시럽이 들어있는 제품",
    "components": [
      "커피",
      "초콜릿 시럽",
      "아몬드"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "273",
      "당류(g)": "25",
      "단백질(g)": "5",
      "포화지방(g)": "7",
      "나트륨(mg)": "82",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 36,
    "name": "초콜릿",
    "tags": [
      "클래식",
      "초코"
    ],
    "kcal": 274,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/aff1c39b1653ddb7701abd9b4c8394ee.png",
    "englishName": "Chocolate",
    "description": "진하고 부드러운 정통 초콜릿 아이스크림",
    "components": [
      "초콜릿"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "274",
      "당류(g)": "24",
      "단백질(g)": "5",
      "포화지방(g)": "8",
      "나트륨(mg)": "85",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 37,
    "name": "바닐라",
    "tags": [
      "바닐라빈",
      "깔끔함"
    ],
    "kcal": 246,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/main/901f131644310c0eb356cbab7ecc4738.png",
    "englishName": "Vanilla",
    "description": "부드럽고 깔끔한 바닐라 아이스크림",
    "components": [
      "바닐라"
    ],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "246",
      "당류(g)": "21",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "74",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 191,
    "name": "베리 굿",
    "tags": [
      "이달의맛",
      "2026년",
      "1월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/843ca147141147c4a4f99491fb0bc4bc.png"
  },
  {
    "id": 173,
    "name": "초콜릿 쿠키 스모어",
    "tags": [
      "이달의맛",
      "2025년",
      "12월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/3c4126478cc7a1eb74dd658c91ff2d16.png"
  },
  {
    "id": 197,
    "name": "골든 프랄린 버터",
    "tags": [
      "이달의맛",
      "2025년",
      "12월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/8732c1dfc2448cea0886bf9200b2f372.png"
  },
  {
    "id": 171,
    "name": "치즈가 브라우니?",
    "tags": [
      "이달의맛",
      "2025년",
      "11월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/c9d03cfcc4348fbf68f9b3b1f2a9b3de.png"
  },
  {
    "id": 500,
    "name": "솔티끼 나 너 초코♥",
    "tags": [
      "이달의맛",
      "2025년",
      "10월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/29a9ad6ca5e7ab1391853bd814bc676f.png"
  },
  {
    "id": 176,
    "name": "위대한 비쵸비",
    "tags": [
      "이달의맛",
      "2025년",
      "9월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/54d138da4091a572845cb65d99d1b0eb.png"
  },
  {
    "id": 288,
    "name": "블루 바나나 브륄레",
    "tags": [
      "이달의맛",
      "2025년",
      "8월"
    ],
    "kcal": 0,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/87354b2b13b50429e93059833134cf49.png",
    "components": [],
    "nutrition": {}
  },
  {
    "id": 164,
    "name": "애망빙",
    "tags": [
      "이달의맛",
      "2025년",
      "7월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/5137d386c0dd249770cb86bcb9838d45.png",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 163,
    "name": "카페오레 초코 크런치",
    "tags": [
      "이달의맛",
      "2025년",
      "6월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/6f7bbdbe0b87639f7b4086b018529139.png",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 162,
    "name": "봄날의 곰을 좋아하세요?",
    "tags": [
      "이달의맛",
      "2025년",
      "5월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/2e35bd8971cdfa94207298feb05420b5.png",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 161,
    "name": "아이스 그린티 킷캣",
    "tags": [
      "이달의맛",
      "2025년",
      "4월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/5196b873a46d413b72665eaaa584d661.png",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 160,
    "name": "말랑 딸기 찹쌀떡",
    "tags": [
      "이달의맛",
      "2025년",
      "3월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/11a73538342122d9d7c392a9616a8b59.png",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 159,
    "name": "아이스 초코 도쿄바나나",
    "tags": [
      "이달의맛",
      "2025년",
      "2월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/888aa0435ec770563c22524a02b2ad17.png",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 158,
    "name": "춘식이의 고구마얌!",
    "tags": [
      "이달의맛",
      "2025년",
      "1월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/dcb3a53eaf20ab21a3233f495561f6a0.png",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 157,
    "name": "키세스 브라우니 초콜릿",
    "tags": [
      "이달의맛",
      "2024년",
      "12월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/68f96de3a18693b46d37c5e91355843c.png",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 156,
    "name": "치토스 밀크쉐이크 아이스크림",
    "tags": [
      "이달의맛",
      "2024년",
      "11월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/89507eab91207c43e790741563d0387f.png",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 155,
    "name": "우석이도 외계인",
    "tags": [
      "이달의맛",
      "2024년",
      "9월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/cd07876cf27e1311344c37ad7bcadacc.png",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 154,
    "name": "피치 Pang 망고 Pang",
    "tags": [
      "이달의맛",
      "2024년",
      "8월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/0457e604adc6249c786c6a50dbfdd200.png",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 153,
    "name": "블루 서퍼 비치",
    "tags": [
      "이달의맛",
      "2024년",
      "7월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/8a893a42a60109e89fb9ee39e728d596.png",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 38,
    "name": "우주 라이크 봉봉",
    "tags": [
      "이달의맛",
      "2024년",
      "6월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/91af0910dba74500ef7353c10bc61ad6.png"
  },
  {
    "id": 152,
    "name": "이상한 나라의 슈팅스타",
    "tags": [
      "이달의맛",
      "2024년",
      "5월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/9aebe3d625f20ffadb2675f0ae24daf4.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 151,
    "name": "아이스 도쿄바나나",
    "tags": [
      "이달의맛",
      "2024년",
      "4월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/6a7c50ed814bd5188603ea31cffa0b07.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 150,
    "name": "탕탕! 스트로베리",
    "tags": [
      "이달의맛",
      "2024년",
      "3월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/6de6fbbf36e0b4fb7f1756e2fa8ce856.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 149,
    "name": "바삭한 쫀꾸렛",
    "tags": [
      "이달의맛",
      "2024년",
      "2월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/1d69ce7e3ff684726bbb4fc2e2f31280.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 39,
    "name": "황치즈 드래곤 볼",
    "tags": [
      "이달의맛",
      "2024년",
      "1월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/4b8f997134cd5b0eda0eeb709474beaf.jpg"
  },
  {
    "id": 148,
    "name": "고디바 다크 크런치",
    "tags": [
      "이달의맛",
      "2023년",
      "12월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/a780948fae58f1256f5ea8dfebff0e05.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 147,
    "name": "도라에몽의 팥붕! 슈붕!",
    "tags": [
      "이달의맛",
      "2023년",
      "11월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/d09aa0a5dcd3845ef806c60e1b6133a6.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 144,
    "name": "초코, 우리 이제 헤이즐넛",
    "tags": [
      "이달의맛",
      "2023년",
      "10월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/9c4bd861eb372a056db535f6dd30c88a.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 146,
    "name": "나는 딸기치오",
    "tags": [
      "이달의맛",
      "2023년",
      "10월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/59f422e827575adcebada41cd047558e.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 142,
    "name": "초코 퐁당 쿠키런",
    "tags": [
      "이달의맛",
      "2023년",
      "9월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/b82195da8f7ae11fa1ce8164f577fa0a.png",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 40,
    "name": "아이스 노티드 우유 생크림",
    "tags": [
      "이달의맛",
      "2023년",
      "8월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/0ca6b4dd68753700a804895e7416bba4.png"
  },
  {
    "id": 141,
    "name": "라이언 망고 마카롱",
    "tags": [
      "이달의맛",
      "2023년",
      "7월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/6131249603c2f09e6f3ccd0104d75086.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 140,
    "name": "시카고 팝콘",
    "tags": [
      "이달의맛",
      "2023년",
      "6월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/5d9919145dc713a9173dc044743e4988.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 41,
    "name": "구름 속 시나모롤",
    "tags": [
      "이달의맛",
      "2023년",
      "5월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/f65ef36400abf52678d5907cf91b6977.jpg"
  },
  {
    "id": 139,
    "name": "복숭아로 피치 올려",
    "tags": [
      "이달의맛",
      "2023년",
      "4월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/dab4342764cf60afed2a4baf30d40aa5.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 137,
    "name": "러브미",
    "tags": [
      "이달의맛",
      "2023년",
      "3월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/221eb035ba12a7220d35ad8ae1c4ac72.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 138,
    "name": "딸기 연유 퐁당",
    "tags": [
      "이달의맛",
      "2023년",
      "3월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/0ba24a92c17a2c27306f06cdf03bcb5a.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 136,
    "name": "아이스 기라델리 초콜릿",
    "tags": [
      "이달의맛",
      "2023년",
      "2월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/0cf86a3b896eda151f5096e78da98242.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 135,
    "name": "벅스 버니버니 당근당근",
    "tags": [
      "이달의맛",
      "2023년",
      "1월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/d3f6dcd61f7a5aa00569d4aea73fc276.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 133,
    "name": "아이스 허쉬 앤 리세스",
    "tags": [
      "이달의맛",
      "2022년",
      "12월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/9ca1199e5f935fac87760b60d9b29c63.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 132,
    "name": "핑크스푼 비긴즈",
    "tags": [
      "이달의맛",
      "2022년",
      "11월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/aa6bcaec2fc71786aad78b05a993c1c6.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 131,
    "name": "짱구가 좋아하는 외계인의 바나나킥",
    "tags": [
      "이달의맛",
      "2022년",
      "10월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/76d30385c72fe332f38c3b8bc44e37fb.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 130,
    "name": "내가 아인슈페너?!",
    "tags": [
      "이달의맛",
      "2022년",
      "9월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/968926102d02724fd487e4c61c0b931d.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 129,
    "name": "아이스 초당옥수수",
    "tags": [
      "이달의맛",
      "2022년",
      "8월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/846ea6694d12beb2b3477687e8341b3b.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 128,
    "name": "마우나로아 마카다미아",
    "tags": [
      "이달의맛",
      "2022년",
      "7월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/ca4ae61e1ed5048adf7b13c18a9d0169.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 127,
    "name": "너로 정했다! 이브이",
    "tags": [
      "이달의맛",
      "2022년",
      "6월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/586928da2d1bf7dd8befe4bcf9504da2.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 126,
    "name": "피카피카 피카츄",
    "tags": [
      "이달의맛",
      "2022년",
      "5월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/15f9523694a257fdd587e7793f14e3a1.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 125,
    "name": "사랑에 빠진 외계인",
    "tags": [
      "이달의맛",
      "2022년",
      "4월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/22b682eb53c72e664ca72168e2e73edb.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 124,
    "name": "오레오 쿠키 앤 스트로베리",
    "tags": [
      "이달의맛",
      "2022년",
      "3월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/7431391259803c22457c617c05b23cfe.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 123,
    "name": "아이스 로아커",
    "tags": [
      "이달의맛",
      "2022년",
      "2월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/3c4f1a11cf14e6ba0c1c44e0143cd03d.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 122,
    "name": "기운 센 아이스 콘푸로스트",
    "tags": [
      "이달의맛",
      "2022년",
      "1월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/cd8daa606e934c0360cb6e90bd0460d2.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 120,
    "name": "아이스 고디바 초콜릿",
    "tags": [
      "이달의맛",
      "2021년",
      "12월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/bb857a9592de10fc60aebcaa8d3cdd23.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 119,
    "name": "치즈나무숲",
    "tags": [
      "이달의맛",
      "2021년",
      "11월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/db9e4e17f3da65cf579a81ad04ae1a48.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 118,
    "name": "찰떡콩떡",
    "tags": [
      "이달의맛",
      "2021년",
      "9월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/25b6751fafb36673e6c2ed87bee989ec.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 117,
    "name": "꿀바망",
    "tags": [
      "이달의맛",
      "2021년",
      "7월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/e8fbc0b80e4bfa75286b8e2ee426bb94.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 116,
    "name": "오버더 레인보우 샤베트",
    "tags": [
      "이달의맛",
      "2021년",
      "6월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/cd5984e5a56098ac83e905e1ac0844b4.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 115,
    "name": "아이스 홈런볼",
    "tags": [
      "이달의맛",
      "2021년",
      "5월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/a53f91747713a8634d515a269f24de05.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 114,
    "name": "민트 초코 봉봉",
    "tags": [
      "이달의맛",
      "2021년",
      "4월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/ab1b884a02073e33d8948abbd3a8dfb1.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 113,
    "name": "아이스 허니버터 아몬드",
    "tags": [
      "이달의맛",
      "2021년",
      "3월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/3a4091ae95e0c81677e29671134b9523.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 112,
    "name": "아이스 밀카 초콜릿",
    "tags": [
      "이달의맛",
      "2021년",
      "2월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/f7f73b8ae2ed571c8dae02d3e9ada2f5.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 111,
    "name": "우유속에 끼인 소보로",
    "tags": [
      "이달의맛",
      "2021년",
      "1월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/b1f44892337418001df249d27ff2e5f3.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 110,
    "name": "아이스 촉촉한 초코칩",
    "tags": [
      "이달의맛",
      "2020년",
      "12월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/0c8febe319a245a6a6cb6b7b991dd76a.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 109,
    "name": "미찐 감자",
    "tags": [
      "이달의맛",
      "2020년",
      "10월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/0b9fa210a22163e666c4521c1a85dad5.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 108,
    "name": "매시업스 시리얼",
    "tags": [
      "이달의맛",
      "2020년",
      "9월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/32ac2b655e0faca683bf077b1d26cf53.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 107,
    "name": "보라보라",
    "tags": [
      "이달의맛",
      "2020년",
      "8월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/236a0c1bf1a15b0f3c735b5ecbd49e9a.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 106,
    "name": "펭수 아슈크림",
    "tags": [
      "이달의맛",
      "2020년",
      "7월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/fb0d19a400be455196fcba6cda053d84.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 105,
    "name": "아몬드 봉봉봉",
    "tags": [
      "이달의맛",
      "2020년",
      "6월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/37524df7eb61e87c6c67679040952caa.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 104,
    "name": "판타스틱 트롤",
    "tags": [
      "이달의맛",
      "2020년",
      "5월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/4e1be0e7ae4eac5fc251fe58246cbe88.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 103,
    "name": "아이스 바나나킥",
    "tags": [
      "이달의맛",
      "2020년",
      "4월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/6d53d26cb9d52c8bff8e89d413971072.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 102,
    "name": "로투스 비스코프",
    "tags": [
      "이달의맛",
      "2020년",
      "3월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/43a08137fa6465645a64fcabeb8ac83a.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 101,
    "name": "아이스 킷캣",
    "tags": [
      "이달의맛",
      "2020년",
      "2월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/bf783fe93c0a54e0ac81d6b8ca45b497.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 177,
    "name": "우리끼리",
    "tags": [
      "이달의맛",
      "2020년",
      "1월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/74282ea4c495b45b9846c29826b9db70.jpg"
  },
  {
    "id": 181,
    "name": "아이스 초코파이 정",
    "tags": [
      "이달의맛",
      "2019년",
      "12월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/72777ae30858a41b88107fdf66e0e857.jpg"
  },
  {
    "id": 178,
    "name": "오레오 쿠키 앤 크림치즈",
    "tags": [
      "이달의맛",
      "2019년",
      "11월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/13dbeb9fe6c7e616e9d611e8da457235.jpg"
  },
  {
    "id": 183,
    "name": "쌀떡궁합",
    "tags": [
      "이달의맛",
      "2019년",
      "9월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/8c4a74f919739626140ff833acf009e3.jpg"
  },
  {
    "id": 184,
    "name": "심슨에 반하나",
    "tags": [
      "이달의맛",
      "2019년",
      "8월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/2c0d3cd69816d8ea5be15f41990686f3.jpg"
  },
  {
    "id": 169,
    "name": "핑크 스타",
    "tags": [
      "이달의맛",
      "2019년",
      "7월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/222ae765355a115598eb149313bab296.jpg"
  },
  {
    "id": 287,
    "name": "블랙 소르베",
    "englishName": "Black Sorbet",
    "kcal": 140,
    "tags": [
      "이달의맛",
      "2019년",
      "6월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/2dd8db12679a75a7c087a3bac4f29084.jpg"
  },
  {
    "id": 182,
    "name": "아이스 죠리퐁",
    "tags": [
      "이달의맛",
      "2019년",
      "5월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/52623c6ce0c50a76e6dd7b67ab53bacf.jpg"
  },
  {
    "id": 286,
    "name": "스트로베리 아보카도",
    "englishName": "Strawberry Avocado",
    "kcal": 240,
    "tags": [
      "이달의맛",
      "2019년",
      "4월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/3ee90a38ebe2c522cb95c3382d8c949c.jpg"
  },
  {
    "id": 285,
    "name": "베리 그래놀라",
    "englishName": "Berry Granola",
    "kcal": 250,
    "tags": [
      "이달의맛",
      "2019년",
      "3월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/37f49d8cdeb6a2441cc29b4e42969f81.jpg"
  },
  {
    "id": 167,
    "name": "허쉬 마카다미아 넛",
    "tags": [
      "이달의맛",
      "2019년",
      "2월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/b3ec07901a76dbb3e15dfe10dc339ed4.jpg"
  },
  {
    "id": 196,
    "name": "꿀꿀허니",
    "tags": [
      "이달의맛",
      "2019년",
      "1월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/6dd1aa5d80a23b7970a84cfb1c7b74ab.jpg"
  },
  {
    "id": 195,
    "name": "누가 크런치",
    "tags": [
      "이달의맛",
      "2018년",
      "12월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/e207c8524bb34f1fb826fe6e446a2d56.jpg"
  },
  {
    "id": 179,
    "name": "오레오 쿠키 앤 카라멜",
    "tags": [
      "이달의맛",
      "2018년",
      "11월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/5abf3f4756b4e6a73aa29a769b265561.jpg"
  },
  {
    "id": 193,
    "name": "몬스터 마시멜로",
    "tags": [
      "이달의맛",
      "2018년",
      "10월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/da77db29d5a02266240c7363a4c5f94b.jpg"
  },
  {
    "id": 175,
    "name": "쫀떡궁합",
    "tags": [
      "이달의맛",
      "2018년",
      "9월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/4bed79da50c8239cad8fa6e41cc70659.jpg"
  },
  {
    "id": 284,
    "name": "베리 스윗 바이올렛",
    "tags": [
      "이달의맛",
      "2018년",
      "8월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/0475d304c29a4f74678ada34df7018e9.jpg"
  },
  {
    "id": 168,
    "name": "핑크퐁 상어가족",
    "tags": [
      "이달의맛",
      "2018년",
      "7월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/a209f9d632335cf439427092a08e405e.jpg"
  },
  {
    "id": 174,
    "name": "체리쥬빌레31",
    "tags": [
      "이달의맛",
      "2018년",
      "6월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/038c010eb2d7aab7e09f77236eaa9e1a.jpg"
  },
  {
    "id": 192,
    "name": "미니미니 미니언즈",
    "tags": [
      "이달의맛",
      "2018년",
      "5월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/c0f8f800d7a15eccc426021ea462e124.jpg"
  },
  {
    "id": 180,
    "name": "야쿠르트 샤베트",
    "tags": [
      "이달의맛",
      "2018년",
      "4월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/536fa7830f114f1f949ff27405e52a57.jpg"
  },
  {
    "id": 172,
    "name": "츄파춥스 스트로베리 앤 크림",
    "tags": [
      "이달의맛",
      "2018년",
      "3월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/3628eeda8cacdf052271261df4a830da.jpg"
  },
  {
    "id": 170,
    "name": "트리플 치즈 러브",
    "tags": [
      "이달의맛",
      "2018년",
      "2월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/0af91a5140f23b5a31349631200206f2.jpg"
  },
  {
    "id": 100,
    "name": "더블 바닐라 초콜릿",
    "tags": [
      "이달의맛",
      "2018년",
      "1월"
    ],
    "kcal": 250,
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/e6545d1f60e4df3d5c67238868b230d9.jpg",
    "components": [],
    "nutrition": {
      "1회 제공량(g)": "115",
      "열량(kcal)": "250",
      "당류(g)": "20",
      "단백질(g)": "4",
      "포화지방(g)": "8",
      "나트륨(mg)": "100",
      "알레르기 성분": "우유"
    }
  },
  {
    "id": 283,
    "name": "보스톤 크림 파이",
    "tags": [
      "이달의맛",
      "2017년",
      "12월"
    ],
    "imageUrl": "https://i.namu.wiki/i/Uyj8iuDItWIFiZx4mg4cae6WDJ2OBGkMGP4hCQvHRZM69f_6l9sdUdsXwpXvvXDglxbu70We8Rt2ulSEwIigtl0x2jvH1ad6ZH2QU9fYE6vRiZlnUry02ItiA0-r_wpHVGlrZj_iuaFxEwWg-Q_WBQ.webp"
  },
  {
    "id": 282,
    "name": "밤이 옥수로 맛있구마",
    "tags": [
      "이달의맛",
      "2017년",
      "11월"
    ],
    "imageUrl": "https://i.namu.wiki/i/KhodsXybyIkt4EiwerIWAvXK0CoiCyeYzujXwOfj33Q89NHyLUnOzXToPcFwmq0OxOxv0_bvZgU50HNImU9EXekQnou4XIdsLUQ4TJfEi1T-rSoulTNbl2qXhcXqaA1Sa0BKjIbE6jK_SFxFqWXzDg.webp"
  },
  {
    "id": 281,
    "name": "너는 참 달고나",
    "tags": [
      "이달의맛",
      "2017년",
      "10월"
    ],
    "imageUrl": "https://i.namu.wiki/i/wKTg1RlwegkUuy-96lKkyyN325JN6Hw-0ZXWVCmhS-yB59m5wSfdg8xiT0AOoEyC4_RkjYvReI-piFF3HDkGNIar1hWVA-A0HD6tmKbjG68kLOGBY9Hi8rBRCaYeEmAQopGIKqS68OFanI7wZLstZw.webp"
  },
  {
    "id": 280,
    "name": "허니 치즈트랩",
    "tags": [
      "이달의맛",
      "2017년",
      "9월"
    ],
    "imageUrl": "https://i.namu.wiki/i/g3E2uroxwNbe070q8ta80KXZNRX-hpVw9f4GoirTVVb8Qh5HDGDDPUM_tkSB4az8_a7kGuXTVDtC3NZIrOY3FzoHSJLzRjkRJ79dngwQolK4JQZ3p5Qj_0qG2SxQad4boSUErCq2mDOp7sW3uVYW5Q.webp"
  },
  {
    "id": 279,
    "name": "트로피칼 아일랜드",
    "tags": [
      "이달의맛",
      "2017년",
      "8월"
    ],
    "imageUrl": "https://i.namu.wiki/i/s9fHyA1yopF1P-4zzyOe2RoaPgQt3XgyyRlUi90Fvpmonp9WajYOUZfB3qR73CrAX6r7pHMvLoQxB6gWWbbXufQKeQdoJuoVIBRIdlF3CIe8Qq8xGoiA7N650Wp3rC6-y2HlqalnegitWPoqFiteBQ.webp"
  },
  {
    "id": 278,
    "name": "스파이더맨 홈 커밍",
    "tags": [
      "이달의맛",
      "2017년",
      "7월"
    ],
    "imageUrl": "https://i.namu.wiki/i/_TO7-SBbEReaDHvNLIXxrTeBbekyXaN23_b9yh-1fD5ZdBhq5Hn0B0W00IYh72fkXbOPQjYBc5p6hU2_IiAC6Q.webp"
  },
  {
    "id": 277,
    "name": "수퍼 펭귄 시리얼",
    "tags": [
      "이달의맛",
      "2017년",
      "6월"
    ],
    "imageUrl": "https://i.namu.wiki/i/VMr1dfQPsBC8FRhDCIF7A7GIvl5-l_IgfyWKLrAl_KsaS3V5KUA1dNa7cu-90St0pUaYivj05RTDIop7eMWhl7KYxfMHqrKHrmXuDKpRwK1U0cjLRf8CppLbQgjgoV1jADrOqvHfXo-x_3tlCB1Hiw.webp"
  },
  {
    "id": 276,
    "name": "팝핑 슈렉",
    "tags": [
      "이달의맛",
      "2017년",
      "5월"
    ],
    "imageUrl": "https://i.namu.wiki/i/o2_MTrJB4Bj6hSUx8qju4ZBl0tWF-QHJ4JognF0gOqKvXmQ8jebEm-qyQyHOE8ALRC5qXJp6AhFw93m-k4d-U_8xCSr6LxhehqrPDRzRm1JQbuHIBwV3rP-w7xsJMGoCz9QtX6VPP7lG6MB97eRqkQ.webp"
  },
  {
    "id": 275,
    "name": "스트라이크 캐슈넛",
    "tags": [
      "이달의맛",
      "2017년",
      "4월"
    ],
    "imageUrl": "https://i.namu.wiki/i/UQ1gvegpSKiSr1tM6u9qFRqGdV1kwLIxsyjUNzSQCX6nQrWTYPxo-ghYkqUp3Gs191ymCkGVMEV8C1KlllY0hCMQDdVFdaFKrF50fiuPawp_dOJd2gDWgkr4YB_469StchoKiW30KhchNIeCME8R-w.webp"
  },
  {
    "id": 274,
    "name": "봉쥬르 마카롱",
    "tags": [
      "이달의맛",
      "2017년",
      "3월"
    ],
    "imageUrl": "https://i.namu.wiki/i/7-ba_1j0bhkrf_kTBEctJfIZsB0twupiv_XUEAv6WecsI7dgQrp8arLyYeyylumhCI2CvbKed462FWB64tZiFyeUKT1fyI5-1aqZVtnIdUw-UOLbQgtlXZrCieHdSx8H7M6GviTGKb-C03mk8xk7HQ.webp"
  },
  {
    "id": 273,
    "name": "키스미 키세스",
    "tags": [
      "이달의맛",
      "2017년",
      "2월"
    ],
    "imageUrl": "https://i.namu.wiki/i/EChEo36i2zRRpcSlR7701X3eqcE5ruT-l-a4gtjXkhMP358-TubqRxNCs2bbX3jmQIe_zuu4atCFa-Cutx36hV0yngjsDmaVDEqPhwmIdbLyHiyeYVokb7eojMIGfSnEW_uvTZLMqiwBoOJ2GEV3jw.webp"
  },
  {
    "id": 272,
    "name": "초코초코 피스타치오",
    "tags": [
      "이달의맛",
      "2017년",
      "1월"
    ],
    "imageUrl": "https://i.namu.wiki/i/kX-QRPd7U6W28gWPyVNVbSU_EPWo31miSJNfdRxiiKHU0A1qccqkVoDsBF3PWl-5UZ4sY1CwRVQI4z4cWdVXXLyabLtNm70uHZa4Y7QTwIeH8yb4wKE9lWrbPqH9Dwh7UwLnCPF7XuIMYiKpYgsEHA.webp"
  },
  {
    "id": 271,
    "name": "민트 초코 홀릭",
    "tags": [
      "이달의맛",
      "2016년",
      "12월"
    ],
    "imageUrl": "https://i.namu.wiki/i/oKPbwNUolRgzEi7k6-6jAf11sn4OniZa1ImJA4q3lEkqXLJSrFjVNsbwOrsto_3-oBoI08rKlV3RV7nIlFO0S9Dy1DXTKRNbWVelUdLoQh-R_lw2cx-0ktwzntz0CnnM9GyyqbedcKX9sntrrWmMkg.webp"
  },
  {
    "id": 270,
    "name": "호두밭의 파수꾼",
    "tags": [
      "이달의맛",
      "2016년",
      "11월"
    ],
    "imageUrl": "https://i.namu.wiki/i/PfT7YjLDuJpxyKSqwAYbQMw-9AFptxImMrDVnyy8GtFtjTZhjsziaybPmeORi9k22XUEV9V_YN5bVp-u4rfs0A.webp"
  },
  {
    "id": 269,
    "name": "핑크 팬더",
    "tags": [
      "이달의맛",
      "2016년",
      "10월"
    ],
    "imageUrl": "https://i.namu.wiki/i/Tgk1J9EpBWdC3puwLWnVzFUm86VuhHqyolHHngcxmXSvEUzasD2K_22h5K8xtj0afs5LqDZJz16cZgjCvw8V8f3sqJtb5B-iM6QMD62v4_JnEtZjDgAm03ciUCRGd7PriWozgEGHVZArRaVRMFK68A.webp"
  },
  {
    "id": 268,
    "name": "콜드브루 카페브리즈",
    "tags": [
      "이달의맛",
      "2016년",
      "9월"
    ],
    "imageUrl": "https://i.namu.wiki/i/pt4z4_l2JqQXS1LtBIimBX__Hh5MqPEvcWHLM81mekpb6wii1H15VKpYZzKNp22A_wXx13MV-68EKbj9cEIi9A.webp"
  },
  {
    "id": 267,
    "name": "골든 애플 요거트",
    "tags": [
      "이달의맛",
      "2016년",
      "8월"
    ],
    "imageUrl": "https://i.namu.wiki/i/PQMwTUsW5502D-yvKZgKISDKl4Tla_WpQlg4G0_IsqQ2uHH2n9UFRU0DyrcVAIgADU2Pi9kgeLbCztz6fk49bCBqGvt-s5gXDzFb3ZtsBXaS4Yqvu4SJPgoBCIkiaVPFA2EnUu22Yr-SpKYWn8FhGg.webp"
  },
  {
    "id": 266,
    "name": "웰컴 투 더 정글",
    "tags": [
      "이달의맛",
      "2016년",
      "7월"
    ],
    "imageUrl": "https://i.namu.wiki/i/2JUllaYPWLfh8oG6X33l3Ha8lY7s58SxKc5tX3H1y7BU2vVaSD7GTY2ojBDLYcyE-ATDrime6C2CUDzEFQ2U_4O5WcuZaNRU_ChP6K5jSNh5QI8UHuWONKMAaBR3MW1T2AuJEwAfroZO_mX8ei7ZMQ.webp"
  },
  {
    "id": 265,
    "name": "다시 돌아온 아이엠 샘",
    "tags": [
      "이달의맛",
      "2016년",
      "6월"
    ],
    "imageUrl": "https://i.namu.wiki/i/vPZwh3pYlD-1xAyCVIuG550fbq7jr6pg0WE9L9Ps4s5VFd1fVnNZenb0zww9E_s26GwhEpqRS1ilqp1t4wMJ37zHuOyIj5IHTqdwbjGSq0-Q0f2EscGj2gGA6Pg8AotAVJ_UF1I0v_sjWkdk9nAanQ.webp"
  },
  {
    "id": 263,
    "name": "캡틴 아메리카",
    "tags": [
      "이달의맛",
      "2016년",
      "4월"
    ],
    "imageUrl": "https://i.namu.wiki/i/65vJMYWXHj6A5YzWYrhrbl0SyN7dKVAv_7U3cNnNLAKCK_GoLAWX6xKZ2IjShf2B2nJszcd50W3kQng8g5-uJrT1e44Eu7LtpOUSlBw7-7VQLDGw6BVrWDLfXB2bKjzIA57ZDZBFyGzzm485CQbEow.webp"
  },
  {
    "id": 262,
    "name": "러브 트레져 초코미키",
    "tags": [
      "이달의맛",
      "2016년",
      "3월"
    ],
    "imageUrl": "https://i.namu.wiki/i/mK8eKN0uSiGdZGTSpf5jHpZVYQRTnozWHSozBvOoDnCuEdHj9E5k4Zrfh5WPqDPuuWDKwPlENjR7m5DnJGb3VIaCuEOFt9gcdloKkdDl3QhUrH41lYy4pb1iX9Qo-oxvNdGiTshnJgSCuvvt7xIHPQ.webp"
  },
  {
    "id": 261,
    "name": "스위스 미스 코코아",
    "tags": [
      "이달의맛",
      "2016년",
      "2월"
    ],
    "imageUrl": "https://i.namu.wiki/i/_0bnuCtmraV5jZX9BAbPXPLLE69P51trnv8-ZpgVvpVNAUpz5hcf7W2mtSHDGaZvzOKndwYwzXSVWXOp4Hrgci2J-6bUB1XTk34UCYChlv4OZ8nkFsS7BufzUv6JR9RUerdvF8_0C82Pn3F9ArAYQA.webp"
  },
  {
    "id": 260,
    "name": "써리 원숭이",
    "tags": [
      "이달의맛",
      "2016년",
      "1월"
    ],
    "imageUrl": "https://i.namu.wiki/i/pNLeGVjlb4eWUysFiar_VA2485OFF_Wm7GC_wXcWQvu6oSycMZrb_mp9-5Hxa0EdEERXcSfF9Ipit44sDN1yhWDSnmolLHVO-dB0dXdUgocg39FNBhdazFO5l2xjHQo_4L0PKBfzBYE1pPu26v13Xg.webp"
  },
  {
    "id": 259,
    "name": "스낵네이도",
    "tags": [
      "이달의맛",
      "2015년",
      "12월"
    ],
    "imageUrl": "https://i.namu.wiki/i/JUTo1CwI_eXZk7_lniFUPtUuSG8xjXRdcnBFZ_4q6DUdQSEG8_JrBabFRuwnaHBsM4C_TL4D-zP2zprF_a_o_CZUIaxA64Dj-tdtWaGfH20Y_oybxK01VD4bQhiwWlybT2M0Feloa2usHGMVioIPcg.webp"
  },
  {
    "id": 258,
    "name": "아포가토",
    "tags": [
      "이달의맛",
      "2015년",
      "11월"
    ],
    "imageUrl": "https://i.namu.wiki/i/pK0CkmsCZdz3eerB0xxzQlLILQSeBfn3oKncc2hqXVlyZi62WIXf7jc4XlA1kn2iAm7rkhqlXpgz13_A6WXHSHdDJeHNQsL93oEGCkCbFDpvNkBVu1WPREorXLBh-1QW0_LIy6JUtQR6ELLkf60zrQ.webp"
  },
  {
    "id": 257,
    "name": "우유 초코볼",
    "tags": [
      "이달의맛",
      "2015년",
      "10월"
    ],
    "imageUrl": "https://i.namu.wiki/i/s4jF00hcSg2TMQ2aoHdBxlw05xfkrjHqEuEVEVBbjnoj8OfFDB1NrB7lhekwsPKA3OLbB_w5pt6CVC96el85S9UBeiKgTIU2BIPvxVtpZvDEnO4ahpMWnQnR7tl19G0bP_8V5UTuCCOyuSt-b7A-2Q.webp"
  },
  {
    "id": 256,
    "name": "바나나 스플릿",
    "tags": [
      "이달의맛",
      "2015년",
      "9월"
    ],
    "imageUrl": "https://i.namu.wiki/i/04PET0XM6fBA5hmAK-lXOXzX4M96DDX9-7HgC2qxbYs2wbTmdbKz-kkyMhpVD5NdxXe2FfLxqWIHN_uOaJANLyErtqW4UDPKZ6rSmBHn5iHaOrsoR_Y1bC4wBObJMa8D2KDI2lbMzN8U6TyCD1bgZA.webp"
  },
  {
    "id": 255,
    "name": "스윗 드롭 치즈케이크",
    "tags": [
      "이달의맛",
      "2015년",
      "8월"
    ],
    "imageUrl": "https://i.namu.wiki/i/w3uW4-vNxHe-cFDx77_P-nk4eR96cS88hC7XQRbtwk0sJTYwGtUKLj7irIgln3LlqOmWi3BW5oeGNeemELcoh25OzlU6E2CU6yLO3BAYSd_WA40o2fcutpGQxkumISSMMk6Yn3yAeGM_-xcdtiv1Kg.webp"
  },
  {
    "id": 254,
    "name": "너티네이도",
    "tags": [
      "이달의맛",
      "2015년",
      "7월"
    ],
    "imageUrl": "https://i.namu.wiki/i/dF1nYx-YEhUZA1bfVALCaroS4eEC9mnTvhv0p3FPQudtfYIjlFRgMJ4FsWCE08quDv_iKOSB2hi7kWuuAbl0y1UlOvbEUvDTnK5bErikP8FXdo6A6nqyzm1PWg7Yu2ZoWInQ9ZUTlcwzzdfEr8JD3g.webp"
  },
  {
    "id": 253,
    "name": "알폰소 망고",
    "tags": [
      "이달의맛",
      "2015년",
      "6월"
    ],
    "imageUrl": "https://i.namu.wiki/i/3SaGwGbJbGmESG8czJKZh3TvJaFGsDVID4ylN3E9YaX4VzK-ah-V7-QGr_oM-incMuNm282J8vY2ahA9FFXht4Y_kzIsTX_VqRL-cS8SecoU2VybttbfQxVm0XNslyOMCgDnFFys5fcpg3syq6Ejhg.webp"
  },
  {
    "id": 252,
    "name": "무비씨어터 팝콘",
    "tags": [
      "이달의맛",
      "2015년",
      "5월"
    ],
    "imageUrl": "https://i.namu.wiki/i/MKikVzeQGZkZEDywmHMZTbGlfxBBxX2TdD-_1-eaVPbPhkQBHsoDcT3z5Kij5xcfjN_dlL-DFVdgeKRGTGeTT4iGeIhmKIYmPdbRD6b40xQq5ZcPA8CZR5TgYd5RGhFm2Sx39uCsJpdWETGxlCe3HA.webp"
  },
  {
    "id": 251,
    "name": "어벤져스",
    "tags": [
      "이달의맛",
      "2015년",
      "4월"
    ],
    "imageUrl": "https://i.namu.wiki/i/QKQQ7Ern0J67ugssYIfkx-497F5C-SVNZWGT2KGHDIKwbE7GcvISrc_YxQ5QWsGY1ZBHOB2h5jFekZ6RI61PMGHix2V0Mph-lX6hK4JzpKSbE1s6p-W8KoP7pSC8zYMk-_5h-Ebe3d0A0rah48dD4A.webp"
  },
  {
    "id": 250,
    "name": "우유에 빠진 딸기",
    "tags": [
      "이달의맛",
      "2015년",
      "3월"
    ],
    "imageUrl": "https://i.namu.wiki/i/rPhASTmE6APngOfPe1wXQhUaNYMHNlJZS36SO44eICg-M02GCWZvpIwO8rWKiOwBb9cy1zlFg06XYltsUEcXJct7zXKFjNo-gUANWdyI-X8gA25VBsPOkOgVE2VCNA6rO4rsAdG95ZjZaOkBRPjZiQ.webp"
  },
  {
    "id": 249,
    "name": "핑크 미니",
    "tags": [
      "이달의맛",
      "2015년",
      "2월"
    ],
    "imageUrl": "https://i.namu.wiki/i/OcVaUHJg3PwpGayzeWZx-AhhmjeynkeXoYoOi0WgIDEQnEW3cZszzjBzS2PGzOj9aloB5nR8WRMn4du_ceVqhIRxKE5_zfQlPnWxYFdPlwdw-NBnOVerrcS71fukUpBtfvYz0MkBavraqeGsBrj2bg.webp"
  },
  {
    "id": 248,
    "name": "순수(秀) 우유",
    "tags": [
      "이달의맛",
      "2015년",
      "1월"
    ],
    "imageUrl": "https://i.namu.wiki/i/IaQUBkXoyd16yobry0GwF_UC9UF2bQGI9etaMydFS6P2_rihmHXk-7PCifQsFb4r2c0vJ8K-PJ8C9wIdPEHoT1RuXV40TQ8V8VJgp2L6vPiHgv46eLYqarEoFK_b9mW-8QprSqD7qmehvIpEZLhImw.webp"
  },
  {
    "id": 247,
    "name": "윈터베리 칩",
    "tags": [
      "이달의맛",
      "2014년",
      "12월"
    ],
    "imageUrl": "https://i.namu.wiki/i/oa9zTzS5-41PKrCZ_bzQxUmcUmxF2djut7u5q1NKU4D86tDZzkvkpTnxwAo2ax4fkEfUMymbJoYvy6KPKDppFX0lLcfvgtZ3cEWlww3dPVLPEjeluRuAUItrj_poNgtLVtE7M644HcciURo0qKn5gA.webp"
  },
  {
    "id": 246,
    "name": "오페라의 유령",
    "tags": [
      "이달의맛",
      "2014년",
      "11월"
    ],
    "imageUrl": "https://i.namu.wiki/i/ztZA2HbQZoDwDzVZ3q6n6Y5qny6K6JM8nhUDmaekAXtwtVHhe9hLgMqDivy4zJ2NNzUnRJU1DHITFe9z5_F7RakmH1dn7AT_YVE1mm7fWULacWvPusI8NN5C_wr_FK6GiKWCGKaxRxk0QQ_m6I8gtg.webp"
  },
  {
    "id": 245,
    "name": "초코나무 숲",
    "tags": [
      "이달의맛",
      "2014년",
      "10월"
    ],
    "imageUrl": "https://i.namu.wiki/i/bcC9nRr3P8pvEj5hsDv3fDxkS637q-MEY0EtZV7m0c2de5uaesadpDb6lB7aIqHg2Ho4cnqx3zxGW_Rm3hJ7IOb4AfvS3bPR8FGj70c-BCjmLUZsZ18ByuMA_f9p7MTC9oI22uI5H3fPWnee5B3_8A.webp"
  },
  {
    "id": 244,
    "name": "엄마는 외계인 10주년",
    "tags": [
      "이달의맛",
      "2014년",
      "9월"
    ],
    "imageUrl": "https://i.namu.wiki/i/L25egWC90UUMqc61sDQBqxFojPyqKmeJnv3rPPivDJYyopa9TXt460uhWxisdKUseMIzvo1UoqIwl3GkU-W-A1r6ufvbXTB3rly2hNZ9gzBtgEBuWuieQHEbSQ6hYFFHnW21HQMhsGJQBVk6NtT_KA.webp"
  },
  {
    "id": 243,
    "name": "요고요고 석류",
    "tags": [
      "이달의맛",
      "2014년",
      "8월"
    ],
    "imageUrl": "https://i.namu.wiki/i/NbOBSLkooNw9hEfs-qGSVIU_MLL7FBkcZ-616DA3IBy-3TY_qdZbVBRpoJLK3uO_SoR8sL-HM8KdD3UTqegtHjEOsOVbek4wiMcXKrlwCDlcV3TFlVHjEKWwKviUXRPo41Jdkw2X7cSXjKfQMeLBNg.webp"
  },
  {
    "id": 242,
    "name": "31일간의 세계여행",
    "tags": [
      "이달의맛",
      "2014년",
      "7월"
    ],
    "imageUrl": "https://i.namu.wiki/i/xTom5TKliFPVkG-QZOCuFRG3x-F8QiUDIWbvWdd2m7a47iNywDU3W7OyKsmxUi5xc36E-_YJ7drHiFjJCzoNbSf_nKfdU6wI56zDu-U_nxRrsxLIYSKNQwZPdnanGBiTV6jTcEXLd8AufCPyOI8LLQ.webp"
  },
  {
    "id": 241,
    "name": "아빠의 싱싱농장",
    "tags": [
      "이달의맛",
      "2014년",
      "6월"
    ],
    "imageUrl": "https://i.namu.wiki/i/V430LlsucOBoHgLuDkeRIbXtp3HQthp6B8-MABueS1Zj_U_ebICs0yVzC-vRr7g2sSHH3Gd9kk2S6PcbrZOJz5st9DWaZNpTCbmBf76PUaM-rJvuzWskiNrZkL_S98fJ6w3WhF6BacXBwznO3dn2NQ.webp"
  },
  {
    "id": 240,
    "name": "우유나라 쿠키볼",
    "tags": [
      "이달의맛",
      "2014년",
      "5월"
    ],
    "imageUrl": "https://i.namu.wiki/i/nZfT664cUKm09awUdGdGNhvokKRfnNIuXb6fEz00Vv7MlyWPGOrP76r93j2ZDJRQiMZQOBR3jR-JnXc-9ajT1fJjLwMRJbg6_B5Yx2v7dA_EeBbp7HUzWk6oV5O3oU4lARrE13jf1i43gMEcQ-dETg.webp"
  },
  {
    "id": 239,
    "name": "어메이징 스파이더맨 2",
    "tags": [
      "이달의맛",
      "2014년",
      "4월"
    ],
    "imageUrl": "https://i.namu.wiki/i/-1p7sv2iqvo7c4LGHPSIFXKsypYdqelwG2kN0wT3EaJhfMJrFkkeQdnAYWoaKTo56HTyVXHEemrCHXw8j2Q1fhHNlNkbWJeHB1pAQu4koq0BBSxZHVJ8ONupfPmWDsgjmdNjmLiY_rI1_B29sXfK8g.webp"
  },
  {
    "id": 238,
    "name": "미스 체리치즈",
    "tags": [
      "이달의맛",
      "2014년",
      "3월"
    ],
    "imageUrl": "https://i.namu.wiki/i/t8PTT5PPDbnwFel_VN5STumjSwKOAkNb2rfX7myHPc0O5DFUM6rtNUHY9SrJuwn34CS5LLV9snd_EkZ_lb5MBXUmZ-dfCYL9uPYLJgAbtEBxnnttuoBcNggWauJDJzzPMOBvQfxyF0UQ-HNW-GdXIA.webp"
  },
  {
    "id": 237,
    "name": "미스터 체리초코",
    "tags": [
      "이달의맛",
      "2014년",
      "2월"
    ],
    "imageUrl": "https://i.namu.wiki/i/aEeLBSWwEXtkhR1GAZWHwb28gMKfTOppqtn1BF4aavpsg8Bvmoti0WCrOCzJPM05NofzzO_Rl9M1YhXfZT1fiHd6WwFT-x0iHTdyH1iFSV7SPCGlCajJL0fPzRyqBPAJ2cBsQcpD8cCvzzPXWoNKGg.webp"
  },
  {
    "id": 236,
    "name": "화이트베리 유니콘",
    "tags": [
      "이달의맛",
      "2014년",
      "1월"
    ],
    "imageUrl": "https://i.namu.wiki/i/g7s4tR7hgx_eY8ZcBpWE48DHr_V6jPxs3WU10ill4kapoaN2bbwSpRv2BNrzc4s7o-MNz5QpvbKRibH6GkIfXZqH5cXFOuM-5MbL18mJsQUkmG0HvyLITSuGCmqEVG5TX76MRpQFzoe_9J3ha-BdLg.webp"
  },
  {
    "id": 235,
    "name": "샘의 초콜릿파이",
    "tags": [
      "이달의맛",
      "2013년",
      "12월"
    ],
    "imageUrl": "https://i.namu.wiki/i/R-FbGLUEfgsRSeobea-QCnnhVl4V4iiH-b9h4cJmRyemLlSb5kw7tRZx_SpZTUeUjQh7WMR4Lyo709xtuZ-itL-CrDGbqXgetsFTiHxx89nfXW4DZSxRU_4Yibxk-aZMGJ_3pN9c22W7OCz6Cv86Aw.webp"
  },
  {
    "id": 234,
    "name": "별빛 카페",
    "tags": [
      "이달의맛",
      "2013년",
      "11월"
    ],
    "imageUrl": "https://i.namu.wiki/i/ji6AlJ_BPQHHG3cyjkAJNWDJpKA__DaBm2-vgXYux1WTbSJvW1SrA_VNmh28KRLTHDgIQ8KbyMfyVzlv2j-JKHQBUgR4ngff9G74hEiIfeYYC01RA3IBFDtSBK-mu6Uoc-ZxMUqLm8oxYacsagBpxQ.webp"
  },
  {
    "id": 233,
    "name": "몬스터 쿠키",
    "tags": [
      "이달의맛",
      "2013년",
      "10월"
    ],
    "imageUrl": "https://i.namu.wiki/i/icaOpDYj8A8E-HYppIEfJZBBge-PmpVjv8m6CYEJ0CoridpALG3JlcM5lRZgyiz3kOT8AR8SOBhWXmozxMHSWE42iYOoHwE_a2JPhf8tYnKMlruaxIEGCR8bSa_5OLNw5_VoSWaodw8UiViTOlsoPg.webp"
  },
  {
    "id": 232,
    "name": "나의 그리스식 요거트",
    "tags": [
      "이달의맛",
      "2013년",
      "9월"
    ],
    "imageUrl": "https://i.namu.wiki/i/EN14u2kXmrWZ5sXCGmeyIk14IbkprD5r0Xb8OMT_iTH64uGgNfHO_WhOtx74ZEh0agDZUYl05FmZ-3ftxB0k3hotsNinSpP6sx7Lq8lSWmp9bR-OSi3pVXaFvONn9qt_8KEmp0xrtmemZOLKLpq5EA.webp"
  },
  {
    "id": 231,
    "name": "알래스카 모카",
    "tags": [
      "이달의맛",
      "2013년",
      "8월"
    ],
    "imageUrl": "https://i.namu.wiki/i/Qrcb7rtVsIXCFWH0vQSAmMxP7-S_rZ2S38Bsdlw1KFeSDQ3lDp2uY_cquFy6xZhnpvHEXZU5RQUEQ-p54xEpkIdGCeViQAvCXGE2TC2vYsQuyooXYYnMM4oZJp_PheNIKbaTXTmP8oYuH42SxBeTyA.webp"
  },
  {
    "id": 230,
    "name": "쿨링쿨링 오션패밀리",
    "tags": [
      "이달의맛",
      "2013년",
      "7월"
    ],
    "imageUrl": "https://i.namu.wiki/i/fm4RF4IcN0F3mju-gw8qkKSq-g9SVnqj9gRHGeABSNzwOh4Czi8HniwhfJOWbs1CfUr-3WUurirhvePRyWmVMdbxwsIfQ-CxpLCR07zQJHPGkV6u0EY5K362crGZg14tPO0eeCLblJ5PxyA73OTEdQ.webp"
  },
  {
    "id": 229,
    "name": "아빠와 팥빙수",
    "tags": [
      "이달의맛",
      "2013년",
      "6월"
    ],
    "imageUrl": "https://i.namu.wiki/i/u6S4OiJobtzOXVx_sm0iJbuOetJIY95qdkLkZSQqoGEhMMDWsJctdhYCwy5-thb2PCThyIDpPzpskvcFbwV1nO2fEJf6v2LiPSS7qOgijXMNhcNRJ2lLQ2jMtyj6IlksFWxBoZGzuUJZfnLeYK0jqA.webp"
  },
  {
    "id": 228,
    "name": "라빈스 선장의 보물상자",
    "tags": [
      "이달의맛",
      "2013년",
      "5월"
    ],
    "imageUrl": "https://i.namu.wiki/i/gJkMj7GmOJ2LD_E7dCigRqQbh20jEelnLAk5CjJdeX2rYFpOXr_uImOgxFCxVwcoRjlf_Xa7nPhpVVdrl4pHVnwK4p4uI_tNHR4lSTz4YXAqAT1wyO4vua58DlJuArRCakmOR_6_6LJbZI6JeHFFYw.webp"
  },
  {
    "id": 227,
    "name": "그린티 티라미수",
    "tags": [
      "이달의맛",
      "2013년",
      "4월"
    ],
    "imageUrl": "https://i.namu.wiki/i/BxgALFGRHmr3J7GapoozabFY7tfQJVkZWYhCtHoPtNdubQbsgKuxE328zJtXwIBjEzvKYCF3ecQu73xVA3ONJoHcoCdjCN2A9lJbxV-ILJd72ee-g6wIVGLvg7SOlhWmoAb2cdUZU26Tckf31W71fA.webp"
  },
  {
    "id": 226,
    "name": "천사의 밀푀유",
    "tags": [
      "이달의맛",
      "2013년",
      "3월"
    ],
    "imageUrl": "https://i.namu.wiki/i/2IVNE4wya7FPlHB3R3xWZD_cAlfw1BJxhd9sn_kd_6n0w0jLj7wF1_HwbAKvU69jrC_mpoCjXPthH8gmSJvYbAdjAl1qd90ad7AIjpGmI0A4RL9lHdu_0JHBfzUdZEWJNc42O78-IF5C0Q3n5ZTxgg.webp"
  },
  {
    "id": 225,
    "name": "악마의 쇼콜라",
    "tags": [
      "이달의맛",
      "2013년",
      "2월"
    ],
    "imageUrl": "https://i.namu.wiki/i/j0SjEQ2NnDZteqbmGOq-zRIve-1NvI5Pq56LJK5ZPlTUifnlrQQo8Yb8YK2yNUy9RcFCQbzsqYXVLgEQoG58jxtEmMtCqu7y-lXe1t1ydsUdsIpqyu1AQY6ZomAog-iaJHG2msKJOjOpjEt4_m-XsQ.webp"
  },
  {
    "id": 224,
    "name": "카라멜 커피 쿠키",
    "tags": [
      "이달의맛",
      "2013년",
      "1월"
    ],
    "imageUrl": "https://i.namu.wiki/i/PQGjakwl7nUOqjGD8gBXOFCM0UZrX1GDR0eXfXqITWpZirgjl2YJpE7vWaOYQk8d2toGvCkt2ZV7hbPVigpGpERy2Ifw6k61SiSgxoSue9nf2c1rDKAyaU8OfbZ-g9NDYYXFRw6yxoJVn8zd787L1Q.webp"
  },
  {
    "id": 223,
    "name": "호두까기 인형",
    "tags": [
      "이달의맛",
      "2012년",
      "12월"
    ],
    "imageUrl": "https://i.namu.wiki/i/lIxDj1TyuXWEoBEA1MuCT_u5po3YAG2kt9m8_jsZSmAG5w6mWohIsvc3vuq-hFBkzwUKq5qJ_OCeOZW9PLNURem5tZBLfTU6z9OSnQtebUaf8aZmCN0PesqbY-lDJ44qprNeDbIMC7q3PZiARtlrYg.webp"
  },
  {
    "id": 222,
    "name": "다크 초코 나이트",
    "tags": [
      "이달의맛",
      "2012년",
      "11월"
    ],
    "imageUrl": "https://i.namu.wiki/i/B2LVZzrGsjZ39kArJBKxD97oS4psqrZNMDwNZce6asw8_7_Qn5ng2WY-Rz8TscOAQmnbqwMv14d2mlH1TG-27znC_4Fyhq_xkA4Lz4_GkLSsJdI5yApwgXV8V28v6JVGqBE0EE0MEy-KsYu_wgqjHQ.webp"
  },
  {
    "id": 221,
    "name": "쿠키 부키",
    "tags": [
      "이달의맛",
      "2012년",
      "10월"
    ],
    "imageUrl": "https://i.namu.wiki/i/JAUZeco1NWbARKAeqGJLJ1o69pzPAUUYp1WNBjOYlrZtA44jbG8MMfWauBnaD-915FWICpcOVTh5Z90Ww0FqfBJVXILgMlJOtJkNITPY-m_KfuZU7clR-k7IJZCaxrWejFGfwzLD7H2x3QTzYAIdBA.webp"
  },
  {
    "id": 220,
    "name": "아이스 카라멜 마끼아또",
    "tags": [
      "이달의맛",
      "2012년",
      "9월"
    ],
    "imageUrl": "https://i.namu.wiki/i/4UFUidcXiIxicZoBS7mYQje6gClTUa1Kn5D3EGMCH1HXDCtZ8tQ8njWAW-FciEVzLrtlQ6GeZyCBQ3EajbsWkWckOgZl1yXPf6dqCaM20se_WL_KcgmIQU3VsS1b25UjPsS4qu1PBESUt6tlZsIRkQ.webp"
  },
  {
    "id": 219,
    "name": "바닐라 스카이",
    "tags": [
      "이달의맛",
      "2012년",
      "8월"
    ],
    "imageUrl": "https://i.namu.wiki/i/MeX9sWazsCFVZD4UmO2srSO2klKjMk4YqV2dFhxQS52YnhYFV-Vb3pLWhUXSRP1Bkkm95i0sjks6MF3hUeOMyCAYPk3cQz_85s3jYn4O4qlwI_WF1Q3M-2lC3s4Gt-IW-eP4WYiuc7UFwH5vkxZyEA.webp"
  },
  {
    "id": 218,
    "name": "마이 레몬 트리",
    "tags": [
      "이달의맛",
      "2012년",
      "7월"
    ],
    "imageUrl": "https://i.namu.wiki/i/QW9c75wPl5MuxRvT8mZDK2FBOfic5tVU3zu7f-aneTkoSUqvHI0ItTikYyMONkeFbuvZ7co4y96fU_EhPSznBYBu9g1LgsnWjhoRymuIl3BvgLKmIacMa3EwyMPKFWZCYu67sVrAHPcR1f-Os2R5Cw.webp"
  },
  {
    "id": 217,
    "name": "올라! 샹그리아",
    "tags": [
      "이달의맛",
      "2012년",
      "6월"
    ],
    "imageUrl": "https://i.namu.wiki/i/qN6hIdVnKyM_ERgJ2xMXPWQmBwsvF0NUpAt6iNXQo7lX6PPDe_Ic9i6WdmFJbA3Ra9GEoXB0U2G5KcvBF1tPPkomg09jJkxZzgnaaE7GF0Yeh92TLlKCm7X5-5SLq0BjK9Iu7kEKtWTA6u5eUPi_Ew.webp"
  },
  {
    "id": 216,
    "name": "디노 젤리",
    "tags": [
      "이달의맛",
      "2012년",
      "5월"
    ],
    "imageUrl": "https://i.namu.wiki/i/EF0TGZifRlF1qLeTpuXUQYmAqX1CzMuh2Y3Og8liRIOe3LLrWI3kT2-YxxSv5WrO9oymAsp-dNk6E0KjgpJIg4cNTNw7LnxJNQVyaSHe1KDuUCvfiMV88Er8jPtzoSOb5f0o9azTZwHzaoQAlJWEDQ.webp"
  },
  {
    "id": 214,
    "name": "솔티 카라멜라",
    "tags": [
      "이달의맛",
      "2012년",
      "3월"
    ],
    "imageUrl": "https://i.namu.wiki/i/vW2cjin_Ux09O6gbDl5SgM5w9RLvUdrJ0AsrNOiitxUHQlZaIoi3Py5Mr3xfJeKBpBzlQyIF6OQ9UDelAmEqQDLJ47_6MgBoU7E5YK7mHlrnc35upEYHxvtzNpEn9M7a8iYLJHWIo6GbcAoB8Ag_WQ.webp"
  },
  {
    "id": 213,
    "name": "네 마음에 퐁당퐁당",
    "tags": [
      "이달의맛",
      "2012년",
      "2월"
    ],
    "imageUrl": "https://i.namu.wiki/i/KRbyVgVyBCazDvsnMQ7MvBGT1YrfahvLdKJoKzQ0eFGb7vIWXlQU1n4UpMayVt4JkZgbNDZx1LsI_fNl8iyE_2JEs68ru4ZqbtK0CVVHTJK9DJyRrFBvLrMXBTbCE-ccR7EzRgdwVF84JyDjvfs-oA.webp"
  },
  {
    "id": 212,
    "name": "아이엠 샘",
    "tags": [
      "이달의맛",
      "2012년",
      "1월"
    ],
    "imageUrl": "https://i.namu.wiki/i/vPZwh3pYlD-1xAyCVIuG550fbq7jr6pg0WE9L9Ps4s5VFd1fVnNZenb0zww9E_s26GwhEpqRS1ilqp1t4wMJ37zHuOyIj5IHTqdwbjGSq0-Q0f2EscGj2gGA6Pg8AotAVJ_UF1I0v_sjWkdk9nAanQ.webp"
  },
  {
    "id": 211,
    "name": "스노우 화이트",
    "tags": [
      "이달의맛",
      "2011년",
      "12월"
    ],
    "imageUrl": "https://i.namu.wiki/i/oa9zTzS5-41PKrCZ_bzQxUmcUmxF2djut7u5q1NKU4D86tDZzkvkpTnxwAo2ax4fkEfUMymbJoYvy6KPKDppFX0lLcfvgtZ3cEWlww3dPVLPEjeluRuAUItrj_poNgtLVtE7M644HcciURo0qKn5gA.webp"
  },
  {
    "id": 210,
    "name": "호두왕자",
    "tags": [
      "이달의맛",
      "2011년",
      "11월"
    ],
    "imageUrl": "https://i.namu.wiki/i/H43d7K1i0WUTaPiHQj2p55hTOyCqvFOYhkULtvxgLATMK0wEa-ST7Magz4m_MhiUt-9yakwaiVOmXOJ0RklzFuY1DgUbNsCNEYLuGNoJDsAbtt-ku0OQ8czxKQ0zSs58bLTFZwbiy8ypAi5J_9oemw.webp"
  },
  {
    "id": 209,
    "name": "미스테리 잭",
    "tags": [
      "이달의맛",
      "2011년",
      "10월"
    ],
    "imageUrl": "https://i.namu.wiki/i/s5NSdUZUlVcOyAgndjD1pKypV9APjq7vDBuX-vaiidGIG9rwBl08Vin01Cyd9ILG4zrNspTDl7ponA5ywHGirU8ZgpIN7H1VG1WIOHu8E4a2xfHmCtuoqloI-RjP5ADccvgbYbwkPvjAqYF_14epWQ.webp"
  },
  {
    "id": 215,
    "name": "땅콩로켓",
    "tags": [
      "이달의맛",
      "2011년",
      "9월"
    ],
    "imageUrl": "https://i.namu.wiki/i/KuL5l-1a2uVkBl4zXQCUp-GVvChmBVpePRFhneNcgpS-IgbqW0-W_0w4H0m7sMfDZRMfAZsi-mq3Px7mjY3aYg.webp"
  },
  {
    "id": 208,
    "name": "빙글빙글 트위스터",
    "tags": [
      "이달의맛",
      "2011년",
      "8월"
    ],
    "imageUrl": "https://i.namu.wiki/i/XXQbzqvIUuvqCSS9y1L3Pt1cn7MmT5tCaSXuQMxiJZO-MJow-_58Ry0WqrcACNrzGiY4hxK4S6k6fiDS2ugW8Nw4TY46rZIMr-fQmyb3rkyzj4Eg05Mta7JpksfeJTR72lGu9Kc4aWSV6mnG6IVuXA.webp"
  },
  {
    "id": 207,
    "name": "파핑 트로피카",
    "tags": [
      "이달의맛",
      "2011년",
      "7월"
    ],
    "imageUrl": "https://i.namu.wiki/i/yqp4MC-_aBzCvWlKozZXdE3jesPuRgpHPJzPesDgYEpBesJKrxkD0pmymIGGJgg3-MsJVDNGMamudxtfzLrnBkG_sskVn0M6RCom6UE38vq_DiHWVLddyWLVAu5qp5yvdgV0Pvi-X0dTpBphjMWGnQ.webp"
  },
  {
    "id": 206,
    "name": "얌베리 요거트의 시크릿 넘버",
    "tags": [
      "이달의맛",
      "2011년",
      "6월"
    ],
    "imageUrl": "https://i.namu.wiki/i/cupoGxzVh14Od_7h1meWppPfQPi7R6ccnvpJUkqciz2WeIbw7oN32P43h_Minb-3rfCLPDRwH41bOZiqcVnyDhI3vJRbbSXpza1QrRUus4A0veBEGsnJghpfMdwPzqmcb1CX5aOMHOSd76VpXefUUw.webp"
  },
  {
    "id": 205,
    "name": "바나나몬스터",
    "tags": [
      "이달의맛",
      "2011년",
      "5월"
    ],
    "imageUrl": "https://i.namu.wiki/i/ji2pjXoAt_rL4Vycq__v-42dtT_iiIuQFqetyU3UAUL5xVRn3akd2g5SXiVRxuHNEuMu4xM2Dk3C-u2BMGaUGLx3kPUnMU2S42rLkXRQ94C6A_17AXhJIBJa4x56yIJ6sPkZVVo4W47-w6oKv-QlNQ.webp"
  },
  {
    "id": 203,
    "name": "블루베리 알로에",
    "tags": [
      "이달의맛",
      "2011년",
      "4월"
    ],
    "imageUrl": "https://i.namu.wiki/i/Anr5GLQvF8jT2mZj_MBoURSyj8vyFXbdsEw1BosBBPd7e_pcakuqIY36LaLdce3K4m7A_vzMXIAIwPFkfY-hXgtCVVx_eKd4UhRVKIfb8FGmuO8-TzJLUOa0c39ax_7m0daTYaGcAOP8J6bLIwOgOg.webp"
  },
  {
    "id": 202,
    "name": "줄리엣의 키스",
    "tags": [
      "이달의맛",
      "2011년",
      "3월"
    ],
    "imageUrl": "https://i.namu.wiki/i/C_jU2JPJ9OI_FneITtznwiyxQaYStsYDNwz88eWF_ttz9Lo3UeMswSdopS0UYEk_VIL5g02RMSpKc2jjlxvCZRPvwzYH6E6YhEig-c3okzbJKYYTOR86OPDcQrD5MRGaFMikD1MWUgi06gIlTqnF5w.webp"
  },
  {
    "id": 201,
    "name": "로미오의 하트",
    "tags": [
      "이달의맛",
      "2011년",
      "2월"
    ],
    "imageUrl": "https://i.namu.wiki/i/aEvI6c7iKkogJB-WvNu5rzT9chauRmUx3tj4lk-CkTVL936jl52INt7iUgQAGL_8F1OeSFdRnYz5tziEvsy1fK3ifEVcRn0jsFSPvwrNI3mI_q8V05zc_7L1m3n4cPelPoCsSSqx7vGiK9wbDNIItg.webp"
  },
  {
    "id": 200,
    "name": "럭키 래빗",
    "tags": [
      "이달의맛",
      "2011년",
      "1월"
    ],
    "imageUrl": "https://i.namu.wiki/i/4n48xIsC92Up3a0AYh1E1PUGA5nbccCTFbOp-uIsfpdQONfZiaJud4b7oC-spwOrjJIkHwhI6bejpoPoAos5jINxDXIWm_XliUFkxPJDTjt6wZqGiaH3UNrP-J2p3XGJc6jDr0N3fg2xNPK3cjlnmQ.webp"
  },
  {
    "id": 204,
    "name": "말차다미아",
    "tags": [
      "이달의맛",
      "2025년",
      "10월"
    ],
    "imageUrl": "https://www.baskinrobbins.co.kr/upload/product/monthBastHistory/ebb08a4a5512fa49d62a2143c2968d0d.png"
  },
  {
    "id": 198,
    "name": "월넛",
    "imageUrl": "https://i.namu.wiki/i/1Ands8OcAogxFLj4XkBcBkTMzBMPQOPJNAa9IrFdmq-xlt9UuPDkmTZcuTSQ94ntrlgqsqyQwMespkOgbfFGWY68GzFFQ8EOnB_8AjbXNou-nA1Irnvg5fHdLWkBs6LED3JyW9p8x-5uQgKB-Qgh0A.webp"
  }
];
